public interface Comparable {
}
