public class GeometricObject {
}
