public interface Cloneable {
}
