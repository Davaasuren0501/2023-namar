public class Home1 {
    public Home1() {
        System.out.println("Mujiin talbai: "+ 1*4/2);
    }
    public static void main(String[] args) {
        new Home1();
    }
}

