package client.product;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.Product;
import db.DbQuery;

@WebServlet("/ControllerProductServlet")
public class ProductServlet extends HttpServlet {
	
	DbQuery dbQuery = new DbQuery();

 @Override
 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     String productName = request.getParameter("productName");
     String productPrice =request.getParameter("productPrice");
     String productQty = request.getParameter("productQty");
//     String productCategory = request.getParameter("productCategory");
     int supplierId = Integer.parseInt( request.getParameter("productSupplier"));
     String productDescription = request.getParameter("productDescription");

     Product product = new Product(1,productName, productQty,productPrice,productDescription,supplierId);

     Product.ProductList.add(product);
     
     request.getRequestDispatcher("/uliral/client/product/list.jsp").forward(request, response);
 }
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	 
	 	dbQuery.selectProduct();
	}
}

