package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.beans.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DbQuery {
	DBUtil dbutil = new DBUtil();
	Connection con;

	
	public void CreateTable() {
		con = dbutil.getConnection();
		createProductTable();
		createSupplierTable();
	}
	
	private void createProductTable() {
        String createTableQuery = "CREATE TABLE IF NOT EXISTS product_product ("
                + "id SERIAL PRIMARY KEY,"
                + "product_name VARCHAR(50) NULL,"
                + "qty VARCHAR(50) NULL, "
                + "price VARCHAR(50) NULL, "
                + "description VARCHAR(50) NULL, "
                + "supplier_id integer NULL"
                + ");";
        try {
            PreparedStatement pst = con.prepareStatement(createTableQuery);
            pst.executeUpdate();
            System.out.println("Sucessfully created product table");
        } catch (SQLException e) {
            System.err.println("Table creation failed: " + e.getMessage());
        }
	}
	
	private void createSupplierTable() {
        String createTableQuery = "CREATE TABLE IF NOT EXISTS supplier_supplier ("
                + "id SERIAL PRIMARY KEY,"
                + "name VARCHAR(50) NULL,"
                + "address VARCHAR(50) NULL, "
                + "phone VARCHAR(50) NULL, "
                + "parent_id Integer NULL"
                + ");";
        try {
            PreparedStatement pst = con.prepareStatement(createTableQuery);
            pst.executeUpdate();
            System.out.println("Sucessfully created supplier_supplier table");
        } catch (SQLException e) {
            System.err.println("Table creation failed: " + e.getMessage());
        }
	}
	public void selectProduct() {
    	String query = "Select * from product_product order by id desc;";
        try {
            PreparedStatement pst = con.prepareStatement(query);
            ResultSet resultSet = pst.executeQuery();
            if (resultSet.next()) {
                int id = resultSet.getInt("id");
                String product_name = resultSet.getString("product_name");
                System.out.println(id);
                System.out.println(product_name);
            }
        } catch (SQLException ex) {
            System.out.print( ex );
        }
    }
	public void selectSupplier() {
    	String query = "Select * from supplier_supplier order by id desc;";
        try {
            PreparedStatement pst = con.prepareStatement(query);
            ResultSet resultSet = pst.executeQuery();
            if (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                System.out.println(id);
                System.out.println(name);
            }
        } catch (SQLException ex) {
            System.out.print( ex );
        }
    }
	
	public int insertProduct(String product_name, String qty, String price, String description, int supplier_id ) {
		String query = "INSERT INTO product_product (product_name, qty, price, description, supplier_id) VALUES (?, ?, ?, ?, ?)";
        int rowCount = 0;
        try {
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, product_name);
            pst.setString(2, qty);
            pst.setString(3, price);
            pst.setString(4, description);
            pst.setInt(5, supplier_id);
            rowCount = pst.executeUpdate();
            return rowCount;
        } catch (SQLException ex) {
            System.out.print( ex );
            return  rowCount;
        }
    }

	
	public int insertSupplier(String name, String address, String phone, int parent_id ) {
		String query = "INSERT INTO supplier_supplier (name, address, phone, parent_id) VALUES (?, ?, ?, ?)";
        int rowCount = 0;
        try {
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, name);
            pst.setString(2, address);
            pst.setString(3, phone);
            pst.setInt(4, parent_id);
            rowCount = pst.executeUpdate();
            return rowCount;
        } catch (SQLException ex) {
            System.out.print( ex );
            return  rowCount;
        }
    }
	
	public int updateSupplier(String name, String address, String phone, int id_update ) {
		String query = "UPDATE supplier_supplier SET name = ?, phone = ?,address = ? WHERE id = ?";
        int rowCount = 0;
        try {
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, name);
            pst.setString(2, phone);
            pst.setString(3,address );
            pst.setInt(4, id_update);
            rowCount = pst.executeUpdate();
            return rowCount;
        } catch (SQLException ex) {
            System.out.print( ex );
            return  rowCount;
        }
    }
	
	public int updateProduct(String product_name, String qty, String price,int supplier_id, int id_update ) {
		String query = "UPDATE product_product SET product_name = ?, qty = ?,price = ?,supplier_id=? WHERE id = ?";
        int rowCount = 0;
        try {
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, product_name);
            pst.setString(2, qty);
            pst.setString(3,price );
            pst.setInt(4,supplier_id );
            pst.setInt(5, id_update);
            rowCount = pst.executeUpdate();
            return rowCount;
        } catch (SQLException ex) {
            System.out.print( ex );
            return  rowCount;
        }
    }

}
